from __future__ import division
from object_library import all_lorentz, Lorentz

# Vortex-Fermion vector structure
VVSS1 = Lorentz(name = 'VVSS1',
                spins = [ 2, 2, 2, 3 ], # Top, W, Bottom, X
                structure = 'Metric(2,4)*ProjM(1,3)')

all_lorentz.append(VVSS1)
