from __future__ import division
from object_library import all_couplings, Coupling

gTSM = Coupling(name = 'gTSM',
                value = 'gTSM',
                order = {'TSM': 1})

all_couplings.append(gTSM)
