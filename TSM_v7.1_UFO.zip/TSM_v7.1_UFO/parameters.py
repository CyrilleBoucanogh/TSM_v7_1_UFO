from __future__ import division
from object_library import all_parameters, Parameter

# Topological Mass of the Fundamental Vacuum Unit (FVU)
MX = Parameter(name = 'MX',
               nature = 'external',
               type = 'real',
               value = 0.870,
               texname = '\\text{M}_X')

# Narrow resonance width
WX = Parameter(name = 'WX',
               nature = 'external',
               type = 'real',
               value = 0.001,
               texname = '\\text{W}_X')

# Coupling constant derived from VAT v7.1 Helicity Correction
gTSM = Parameter(name = 'gTSM',
                nature = 'external',
                type = 'real',
                value = 0.001166,
                texname = 'g_{TSM}')

all_parameters.append(MX)
all_parameters.append(WX)
all_parameters.append(gTSM)
