from __future__ import division
from object_library import all_vertices, Vertex
import particles as P
import couplings as CP
import lorentz as L

# The VAT Decay Vertex: top quark shedding one X-vortex unit
V_1 = Vertex(name = 'V_1',
             particles = [ P.all_particles.t, P.all_particles.W__plus__, P.all_particles.b, P.all_particles.X ],
             color = [ 'Identity(1,3)' ],
             lorentz = [ L.VVSS1 ],
             couplings = {(0,0): CP.gTSM})

all_vertices.append(V_1)
