# TSM v7.0 - Parameters definition
from object_library import all_parameters, Parameter

# Масса Аэфирона (0.870 GeV)
MX = Parameter(name = 'MX',
               nature = 'external',
               type = 'real',
               value = 0.870,
               texname = '\\text{M}_X')

# Ширина распада (очень узкая, так как это структурный дефект)
WX = Parameter(name = 'WX',
               nature = 'external',
               type = 'real',
               value = 0.001,
               texname = '\\text{W}_X')

# Константа связи (выведенная из VAT N_i)
gTSM = Parameter(name = 'gTSM',
                nature = 'external',
                type = 'real',
                value = 0.0073,        # Ваш расчетный дефект
                texname = 'g_{TSM}')

all_parameters.append(MX)
all_parameters.append(WX)
all_parameters.append(gTSM)
